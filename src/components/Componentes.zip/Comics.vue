<script setup></script>
<template>
    <h1>MUY PRONTO!</h1>
</template>
<style scoped>
h1 {
    position: absolute;
    top: 200px;
    width: 500px;
    color: whitesmoke;
    left: 50%;
    transform: translate(-50%);
    text-align: center;
    animation: blur-in 2s linear;
}
</style>